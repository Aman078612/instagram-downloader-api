# Instagram Video Downloader API

A Flask-based API to extract direct MP4 download links from Instagram videos using `yt-dlp`.

## How to Use

1. Install requirements:
```
pip install -r requirements.txt
```

2. Run the API:
```
python app.py
```

3. POST to `/api/download` with form-data:
- `url`: Instagram video/reel URL

## Deployment on Render.com

- Add this repo to GitHub
- Create a new Web Service on Render
- Set the Start Command to: `python app.py`
